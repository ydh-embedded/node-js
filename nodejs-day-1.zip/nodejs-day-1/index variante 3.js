require('dotenv').config;

const express   = require('express');
const app       = express();
const PORT      = process.env.PORT || 3000;

app.get('/',(request,response) => {                                             //wir verwenden die lambda Function  mit den Parametern Anfrage und Antwort vom Server
    response.send('Our first Node.js webServer');                               // Hier wird die Antwort vom Server gesendet localhos:3000 zeigt den Text-String jetzt an.

});


// Route für eine einzelne Datei mit sendFile
app.get('/html-example',(request,response) => {                                 // wir verwenden die lambda Function  mit den Parametern Anfrage und Antwort vom Server
    
    try {                                                                           // mit der html-example legen wir eine Route an
        response.sendFile('public/example-page.html' , { root: __dirname});         // wir legen das root-Verzeichniss fest
    }   catch (error){
        console.log(error);
    }

});





app.listen(PORT, () => console.log(`Server running on Port ${PORT}`));

