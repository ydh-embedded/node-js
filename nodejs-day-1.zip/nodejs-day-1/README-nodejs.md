# nodejs

terminal öffnen und mit npm init

[Heroku](https://www.heroku.com/nodejs)


## .env anlegen

DB_HOST     =   localhost
DB_USER     =   nodejs-user
DB_NAME     =   nodejs_db
DB_PASSWORT =   +Schenker1

PORT=5400  