require('dotenv').config;
console.log('Hello HOST: '          + process.env.DB_HOST);
console.log('Datenbanknutzer: '     + process.env.DB_USER);
console.log('Datenbankname: '       + process.env.DB_NAME);
console.log('Datenbankpasswort: '   + process.env.DB_PASSWORD);
