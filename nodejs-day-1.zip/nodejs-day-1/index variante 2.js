require('dotenv').config;

const express   = require('express');
const app       = express();
const PORT      = process.env.PORT || 3000;

app.get('/',(request,response) => {                                             //wir verwenden die lambda Function  mit den Parametern Anfrage und Antwort vom Server
    response.send('Our first Node.js webServer');                               // Hier wird die Antwort vom Server gesendet localhos:3000 zeigt den Text-String jetzt an.

});
app.get('/:youRname',(request,response) => {                                    // wir verwenden die lambda Function  mit den Parametern Anfrage und Antwort vom Server
    response.send('youRname; ' + request.params.youRname);                      // mit der Variable :youRname legen wir eine Route an

});

app.listen(PORT, () => console.log(`Server running on Port ${PORT}`));

