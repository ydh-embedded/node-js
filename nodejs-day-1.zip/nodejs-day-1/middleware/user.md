	users_id	users_name	users_password	users_registered	users_last_login	

## Datenbank einbinden
mit phpMyAdmin importieren